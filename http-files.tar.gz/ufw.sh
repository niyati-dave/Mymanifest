#!/bin/bash
ufw enable
ufw allow 22
ufw allow 80
ufw allow 443

