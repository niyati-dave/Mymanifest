#!/bin/sh
export http_proxy="http://10.135.80.164:8678"
cd /usrdata/archive
wget http://sourceforge.net/projects/pcre/files/pcre/8.36/pcre-8.36.tar.gz/download
cp download pcre-8.36.tar.gz
tar -zxvf pcre-8.36.tar.gz
cd pcre-8.36
./configure --prefix=/usrdata/apps/syspacks/pcre/ --enable-utf --enable-unicode-properties
make
make install 
cd ..
rm –rf pcre-8.36

#############httpd##########################
cd /usrdata/archive
wget http://apache.petsads.us//httpd/httpd-2.4.10.tar.gz
tar -zxvf httpd-2.4.10.tar.gz
cp -R /usrdata/archive/apr-1.5.1 /usrdata/archive/httpd-2.4.10/srclib/apr
cp -R /usrdata/archive/apr-util-1.5.4 /usrdata/archive/httpd-2.4.10/srclib/apr-util
cd /usrdata/archive/httpd-2.4.10
./configure \
	--with-included-apr \
	--with-pcre=/usrdata/apps/syspacks/pcre/ \
	--with-openssl=/usr/bin/ \
	--prefix=/usrdata/apps/httpserver/ \
	--with-crypto \
	--enable-mods-shared=all \
	--enable-alias \
	--enable-allowmethods \
	--enable-asis \
	--enable-authz_host \
	--enable-bucketeer \
	--enable-cache \
	--enable-cache_socache \
	--enable-cache_disk \
	--enable-case_filter \
	--enable-case_filter_in \
	--enable-dav \
	--enable-disk_cache \
	--enable-echo \
	--enable-expires \
	--enable-file_cache \
	--enable-headers \
	--enable-heartbeat \
	--enable-heartmonitor \
	--enable-log_config \
	--enable-log_forensic \
	--enable-mime \
	--enable-mime_magic \
	--enable-proxy \
	--enable-proxy_ajp \
	--enable-proxy_balancer \
	--enable-proxy_connect \
	--enable-proxy_express \
	--enable-proxy_http \
	--enable-ratelimit \
	--enable-remoteip \
	--enable-rewrite \
	--enable-session \
	--enable-session_cookie \
	--enable-session_crypto \
	--enable-session_dbd \
	--enable-ssl \
	--enable-status \
	--enable-unique_id \
	--enable-usertrack

make
make install
#rm -rf /usrdata/archive/httpd-2.4.10

cd /usrdata/archive
wget http://www.poolsaboveground.com/apache/tomcat/tomcat-connectors/jk/tomcat-connectors-1.2.40-src.tar.gz
tar -zxvf tomcat-connectors-1.2.40-src.tar.gz
cd  tomcat-connectors-1.2.40-src/native
./configure --with-apxs=/usrdata/apps/httpserver/bin/apxs --with-apr-config=/usrdata/apps/httpserver/bin/apr-1-config
make
make install
cd ..
rm -rf tomcat-connectors-1.2.40-src





