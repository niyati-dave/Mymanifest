#!/bin/bash
cd /usrdata/archive
export http_proxy=http://10.135.80.164:8678/
wget http://mirror.symnds.com/software/Apache/apr/apr-1.5.1.tar.gz
tar -zxvf apr-1.5.1.tar.gz
cd apr-1.5.1
./configure --prefix=/usrdata/apps/sysapps/apr
make 
make install
cd ..
#rm -rf apr-1.5.1
cd /usrdata/archive
wget http://mirror.symnds.com/software/Apache/apr/apr-util-1.5.4.tar.gz
tar -zxvf apr-util-1.5.4.tar.gz
cd apr-util-1.5.4
./configure --prefix=/usrdata/apps/sysapps/apr-util --with-apr=/usrdata/apps/sysapps/apr
make
make install
cd ..
rm -rf apr-util-1.5.4
wget http://www.eng.lsu.edu/mirrors/apache/tomcat/tomcat-connectors/native/1.1.32/source/tomcat-native-1.1.32-src.tar.gz
tar -zxvf tomcat-native-1.1.32-src.tar.gz
cd tomcat-native-1.1.32-src/jni/native
./configure --prefix=/usrdata/apps/sysapps/tomcat-native --with-apr=/usrdata/apps/sysapps/apr --with-java-usrdata=$JAVA_HOME --with-ssl=yes
make
make install
cd ../../../
rm -rf tomcat-native-1.1.29-src
cp /usrdata/apps/appserver/apache-tomcat-8.0.18/conf/server.xml /usrdata/apps/appserver/apache-tomcat-8.0.18/conf/server.xml-orig
cp /usrdata/apps/appserver/apache-tomcat-8.0.18/conf/catalina.properties /usrdata/apps/appserver/apache-tomcat-8.0.18/conf/catalina.properties-orig
