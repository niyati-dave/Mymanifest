#!/bin/sh
export JAVA_OPTS="$JAVA_OPTS\
 -Djava.awt.headless=true\
 -Dfile.encoding=UTF-8\
 -server\
 -Xms10g\
 -Xmx20g\
 -XX:NewSize=512m\
 -XX:MaxNewSize=1g\
 -XX:PermSize=1g\
 -XX:MaxPermSize=3g\
 -XX:+DisableExplicitGC\
 -XX:+HeapDumpOnOutOfMemoryError\
 -XX:HeapDumpPath=/usrdata/logs/tomcatlogs/heapdump\
 -XX:SurvivorRatio=12\
 -XX:MaxTenuringThreshold=0\
 -XX:+UseConcMarkSweepGC\
 -XX:+CMSIncrementalMode\
 -XX:+CMSIncrementalPacing\
 -XX:+CMSClassUnloadingEnabled\
 -XX:+DisableExplicitGC\
 -XX:+UseParNewGC\
 -XX:+UseTLAB\
 -Djio.tomcatlog.base=/usrdata/logs/tomcatlogs\
 -Djio.tomcatlog.archive=/usrdata/logs/tomcatlogs/archive\
 -Djio.applog.base=/usrdata/logs/applogs\
 -Djio.applog.archive=/usrdata/logs/applogs/archive\
 -Djio.log.prefix=event-app-dss1\
 -Djio.env=prod"

chown jersey:servicesusrgroup /usrdata/apps/appserver/apache-tomcat-7.0.56/bin/setenv.sh

chmod +x /usrdata/apps/appserver/apache-tomcat-7.0.56/bin/setenv.sh


