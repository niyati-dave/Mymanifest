#!/bin/bash
###############Mod Evasive###################
cd /usrdata/archive/
wget http://www.zdziarski.com/blog/wp-content/uploads/2010/02/mod_evasive_1.10.1.tar.gz
tar -xvf mod_evasive_1.10.1.tar.gz
cd mod_evasive/
cp mod_evasive{20,24}.c
sed s/remote_ip/client_ip/g -i mod_evasive24.c
/usrdata/apps/httpserver/bin/apxs -cia mod_evasive24.c
cd ..
rm -rf mod_evasive
###########mod_qos#############
cd /usrdata/archive
wget http://downloads.sourceforge.net/project/mod-qos/mod_qos-11.7.tar.gz?r=http%3A%2F%2Fsourceforge.net%2Fprojects%2Fmod-qos%2Ffiles%2F&ts=1419011313&use_mirror=liquidtelecom
mv mod_qos-11.7.tar.gz\?r\=http%3A%2F%2Fsourceforge.net%2Fprojects%2Fmod-qos%2Ffiles%2F mod_qos-11.7.tar.gz
tar -xvf mod_qos-11.7.tar.gz
cd mod_qos-11.7/apache2/
export C_INCLUDE_PATH=/usrdata/apps/syspacks/pcre/include
/usrdata/apps/httpserver/bin/apxs -i -c  mod_qos.c  
cd ../../
rm -rf mod_qos-11.7
######mod_Security############
######install python first#############
mkdir /usrdata/apps/syspacks/python3.4.2
wget https://www.python.org/ftp/python/3.4.2/Python-3.4.2.tgz
tar -xvf Python-3.4.2.tgz
cd Python-3.4.2
./configure --prefix=/usrdata/apps/syspacks/python3.4.2  
make && make install
cd ..
rm -rf Python-3.4.2
########### install libxml2################
mkdir /usrdata/apps/syspacks/libxml2
cd /usrdata/archive
wget http://xmlsoft.org/sources/libxml2-2.9.2.tar.gz
tar -xvf libxml2-2.9.2.tar.gz
cd libxml2-2.9.2
./configure --prefix=/usrdata/apps/syspacks/libxml2/ --with-python=/usrdata/apps/syspacks/python3.4.2 --disable-static --with-history
make
make install
cd ..
rm -rf libxml2-2.9.2
###############install Mod Security#################
mkdir /usrdata/apps/syspacks/mod-security
cd /usrdata/archive
wget https://www.modsecurity.org/tarball/2.8.0/modsecurity-2.8.0.tar.gz
tar -xvf modsecurity-2.8.0.tar.gz
cd modsecurity-2.8.0/
/configure --prefix=/usrdata/apps/syspacks/mod-security/ \ 
            --with-libxml=/usrdata/apps/syspacks/libxml2/ \
            --with-apr=/usrdata/apps/httpserver/bin/apr-1-config \
            --with-apu=/usrdata/apps/httpserver/bin/apu-1-config \
            --with-apxs=/usrdata/apps/httpserver/bin/apxs \
            --with-pcre=/usrdata/apps/syspacks/pcre/ \
            --with-lua
make && make install
cd ..
rm -rf modsecurity-2.8.0
###COnfigure server to start using security#################
cd /usrdata/archive
make && make install
cd ..
rm -rf modsecurity-2.8.0
mv /usrdata/archive/owasp-modsecurity-crs-master /usrdata/apps/httpserver/mod-security-rules/mod-security-rules
cd /usrdata/apps/httpserver/mod-security-rules/mod-security-rules/owasp-modsecurity-crs-master
mv modsecurity_crs_10_setup.conf.example modsecurity_crs_10_setup.conf
